<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <title>Club de Tennis</title>
    <link rel="stylesheet" href="css/footer.css">
    <link href="https://fonts.googleapis.com/css2?family=Tenor+Sans&display=swap" rel="stylesheet" type="text/css">
</head>

<body>
    <div class="footer">
        <div class="footer-content">
            <p class="footer-left">Tennis4Ever</p>
            <p class="footer-right">
                <a href="cgu.php">Mentions légales</a> |
                <a href="cgu.php">Conditions générales d'utilisation</a>
            </p>
        </div>
    </div>
</body>

</html>